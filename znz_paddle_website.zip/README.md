# ZnZ Paddle Website

This is the website for ZnZ Paddle paddle board and inflatable boat rental service.

## How to use

- Upload the files to GitHub in a repository named `znzpaddle.github.io` to host the website with GitHub Pages.
- The website files include:
  - index.html: main website page
- Contact info and pricing are in the HTML and can be edited.

## Contact

Email: znzpaddle@gmail.com  
Phone: 604-417-3142
